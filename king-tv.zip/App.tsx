
import React, { useState, useEffect, useCallback } from 'react';
import { 
  AlertCircle
} from 'lucide-react';
import { AppState, ViewState, AuthResponse, Stream, Category } from './types';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import ContentList from './components/ContentList';
import Player from './components/Player';
import Settings from './components/Settings';
import * as xtream from './services/xtream';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    view: 'LOGIN',
    auth: null,
    selectedCategory: null,
    selectedStream: null,
    host: localStorage.getItem('iptv_host') || 'http://your-iptv-dns.com:8080'
  });

  const [categories, setCategories] = useState<Category[]>([]);
  const [streams, setStreams] = useState<Stream[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const navigate = (view: ViewState) => {
    setState(prev => ({ ...prev, view }));
  };

  const handleLogin = (auth: AuthResponse, host: string) => {
    localStorage.setItem('iptv_host', host);
    setState(prev => ({ ...prev, auth, host, view: 'DASHBOARD' }));
  };

  const handleLogout = () => {
    setState(prev => ({ ...prev, auth: null, view: 'LOGIN' }));
  };

  const fetchCategories = useCallback(async (type: 'live' | 'movie' | 'series') => {
    if (!state.auth) return;
    setLoading(true);
    try {
      const data = await xtream.getCategories(state.host, state.auth.user_info.username, state.auth.user_info.password || '', type);
      setCategories(data);
    } catch (err) {
      setError('Failed to fetch categories');
    } finally {
      setLoading(false);
    }
  }, [state.auth, state.host]);

  const fetchStreams = useCallback(async (type: 'live' | 'movie' | 'series', categoryId?: string) => {
    if (!state.auth) return;
    setLoading(true);
    try {
      const data = await xtream.getStreams(state.host, state.auth.user_info.username, state.auth.user_info.password || '', type, categoryId);
      setStreams(data);
    } catch (err) {
      setError('Failed to fetch streams');
    } finally {
      setLoading(false);
    }
  }, [state.auth, state.host]);

  useEffect(() => {
    if (state.view === 'LIVE_TV') {
      fetchCategories('live');
      fetchStreams('live');
    } else if (state.view === 'MOVIES') {
      fetchCategories('movie');
      fetchStreams('movie');
    } else if (state.view === 'SERIES') {
      fetchCategories('series');
      fetchStreams('series');
    }
  }, [state.view, fetchCategories, fetchStreams]);

  const handleSelectStream = (stream: Stream) => {
    setState(prev => ({ ...prev, selectedStream: stream, view: 'PLAYER' }));
  };

  const renderContent = () => {
    switch (state.view) {
      case 'LOGIN':
        return <Login onLogin={handleLogin} initialHost={state.host} />;
      case 'DASHBOARD':
        return <Dashboard auth={state.auth!} navigate={navigate} onLogout={handleLogout} />;
      case 'LIVE_TV':
      case 'MOVIES':
      case 'SERIES':
        const type = state.view === 'LIVE_TV' ? 'live' : state.view === 'MOVIES' ? 'movie' : 'series';
        return (
          <ContentList 
            type={type}
            categories={categories}
            streams={streams}
            loading={loading}
            onSelectStream={handleSelectStream}
            onBack={() => navigate('DASHBOARD')}
            onCategoryChange={(catId) => fetchStreams(type, catId)}
          />
        );
      case 'PLAYER':
        return (
          <Player 
            stream={state.selectedStream!} 
            host={state.host}
            username={state.auth?.user_info.username || ''}
            password={state.auth?.user_info.password || ''}
            onBack={() => navigate(state.selectedStream?.stream_type === 'movie' ? 'MOVIES' : state.selectedStream?.stream_type === 'series' ? 'SERIES' : 'LIVE_TV')}
          />
        );
      case 'SETTINGS':
        return <Settings auth={state.auth!} host={state.host} onBack={() => navigate('DASHBOARD')} setHost={(h) => setState(prev => ({...prev, host: h}))} />;
      default:
        return <Dashboard auth={state.auth!} navigate={navigate} onLogout={handleLogout} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-black text-white selection:bg-red-600 selection:text-white">
      {renderContent()}
      
      {error && (
        <div className="fixed bottom-4 right-4 bg-red-800 text-white px-6 py-3 rounded-lg shadow-2xl flex items-center gap-3 animate-bounce">
          <AlertCircle size={20} />
          <span>{error}</span>
          <button onClick={() => setError(null)} className="ml-2 hover:opacity-75">✕</button>
        </div>
      )}
    </div>
  );
};

export default App;
