
import { AuthResponse, Category, Stream } from '../types';

export const authenticate = async (host: string, user: string, pass: string): Promise<AuthResponse | null> => {
  try {
    const response = await fetch(`${host}/player_api.php?username=${user}&password=${pass}`);
    const data = await response.json();
    if (data.user_info && data.user_info.auth === 1) {
      return data;
    }
    return null;
  } catch (error) {
    console.error('Auth error:', error);
    return null;
  }
};

export const getCategories = async (host: string, user: string, pass: string, type: 'live' | 'movie' | 'series'): Promise<Category[]> => {
  const action = type === 'live' ? 'get_live_categories' : type === 'movie' ? 'get_vod_categories' : 'get_series_categories';
  try {
    const response = await fetch(`${host}/player_api.php?username=${user}&password=${pass}&action=${action}`);
    return await response.json();
  } catch (error) {
    return [];
  }
};

export const getStreams = async (host: string, user: string, pass: string, type: 'live' | 'movie' | 'series', categoryId?: string): Promise<Stream[]> => {
  let action = '';
  if (type === 'live') action = 'get_live_streams';
  else if (type === 'movie') action = 'get_vod_streams';
  else action = 'get_series_streams';

  const catParam = categoryId && categoryId !== 'all' ? `&category_id=${categoryId}` : '';
  
  try {
    const response = await fetch(`${host}/player_api.php?username=${user}&password=${pass}&action=${action}${catParam}`);
    return await response.json();
  } catch (error) {
    return [];
  }
};

export const getStreamUrl = (host: string, user: string, pass: string, streamId: number, extension: string = 'ts'): string => {
  return `${host}/live/${user}/${pass}/${streamId}.${extension}`;
};

export const getVodUrl = (host: string, user: string, pass: string, streamId: number, extension: string = 'mp4'): string => {
  return `${host}/movie/${user}/${pass}/${streamId}.${extension}`;
};

export const getSeriesUrl = (host: string, user: string, pass: string, streamId: number, extension: string = 'mp4'): string => {
  return `${host}/series/${user}/${pass}/${streamId}.${extension}`;
};
