
import React, { useState } from 'react';
import { User, Lock, Globe, ArrowRight, Loader2, Crown } from 'lucide-react';
import { AuthResponse } from '../types';
import * as xtream from '../services/xtream';

interface LoginProps {
  onLogin: (auth: AuthResponse, host: string) => void;
  initialHost: string;
}

const Login: React.FC<LoginProps> = ({ onLogin, initialHost }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [host, setHost] = useState(initialHost);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showAdminSettings, setShowAdminSettings] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password || !host) {
      setError('Por favor complete todos los campos');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const response = await xtream.authenticate(host, username, password);
      if (response) {
        onLogin({ ...response, user_info: { ...response.user_info, password } }, host);
      } else {
        setError('Credenciales inválidas o host no alcanzable');
      }
    } catch (err) {
      setError('Error de conexión. Verifique el DNS o internet.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#050505] relative overflow-hidden">
      {/* Background Blur Effects */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-red-900/20 blur-[120px] rounded-full"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-red-900/20 blur-[120px] rounded-full"></div>
      
      <div className="w-full max-w-md bg-zinc-900/40 backdrop-blur-3xl p-8 rounded-[2.5rem] border border-red-900/20 shadow-2xl relative z-10">
        <div className="text-center mb-10">
          <div className="bg-red-700 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-xl shadow-red-900/40 transform -rotate-3 hover:rotate-0 transition-transform duration-500">
            <Crown size={48} className="text-white" />
          </div>
          <h1 className="text-4xl font-black tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-white via-red-200 to-red-500">
            KING TV
          </h1>
          <p className="text-zinc-500 mt-2 font-medium tracking-wide">Premium Access Only</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-zinc-400 ml-4 uppercase tracking-widest">Usuario</label>
            <div className="relative group">
              <User className="absolute left-5 top-1/2 -translate-y-1/2 text-zinc-600 group-focus-within:text-red-500 transition-colors" size={18} />
              <input 
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Nombre de usuario"
                className="w-full bg-zinc-900/60 border border-zinc-800 rounded-2xl py-4 pl-14 pr-5 focus:outline-none focus:ring-2 focus:ring-red-600 focus:border-transparent transition-all placeholder:text-zinc-700 text-white"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-zinc-400 ml-4 uppercase tracking-widest">Contraseña</label>
            <div className="relative group">
              <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-zinc-600 group-focus-within:text-red-500 transition-colors" size={18} />
              <input 
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-zinc-900/60 border border-zinc-800 rounded-2xl py-4 pl-14 pr-5 focus:outline-none focus:ring-2 focus:ring-red-600 focus:border-transparent transition-all placeholder:text-zinc-700 text-white"
              />
            </div>
          </div>

          {showAdminSettings && (
            <div className="space-y-1.5 pt-2 animate-in slide-in-from-top duration-300">
              <label className="text-xs font-bold text-red-500 ml-4 uppercase tracking-widest">Hosting DNS</label>
              <div className="relative group">
                <Globe className="absolute left-5 top-1/2 -translate-y-1/2 text-red-700" size={18} />
                <input 
                  type="text"
                  value={host}
                  onChange={(e) => setHost(e.target.value)}
                  placeholder="http://host:port"
                  className="w-full bg-red-950/10 border border-red-900/30 text-red-100 rounded-2xl py-4 pl-14 pr-5 focus:outline-none focus:ring-2 focus:ring-red-600 transition-all"
                />
              </div>
            </div>
          )}

          {error && (
            <div className="bg-red-500/10 border border-red-500/20 py-3 rounded-2xl px-4 flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></div>
              <p className="text-red-400 text-xs font-bold uppercase tracking-tight">{error}</p>
            </div>
          )}

          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-red-600 hover:bg-red-700 active:scale-[0.98] text-white font-black py-4 rounded-2xl flex items-center justify-center gap-3 transition-all shadow-xl shadow-red-950/20 disabled:opacity-50 disabled:cursor-not-allowed uppercase tracking-widest"
          >
            {loading ? <Loader2 className="animate-spin" size={24} /> : (
              <>
                Entrar al Sistema
                <ArrowRight size={20} />
              </>
            )}
          </button>
        </form>

        <div className="mt-8 flex justify-center">
          <button 
            onClick={() => setShowAdminSettings(!showAdminSettings)}
            className="text-[10px] text-zinc-600 hover:text-red-500 transition-colors flex items-center gap-1 font-bold uppercase tracking-tighter"
          >
            {showAdminSettings ? 'Ocultar Config' : 'Configuración DNS'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Login;
