
import React from 'react';
import { Tv, Film, PlaySquare, Settings, LogOut, User, Clock, Crown } from 'lucide-react';
import { AuthResponse, ViewState } from '../types';

interface DashboardProps {
  auth: AuthResponse;
  navigate: (view: ViewState) => void;
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ auth, navigate, onLogout }) => {
  const menuItems = [
    { id: 'LIVE_TV', label: 'En Vivo', icon: Tv, color: 'bg-red-700', hover: 'hover:bg-red-800' },
    { id: 'MOVIES', label: 'Películas', icon: Film, color: 'bg-zinc-800', hover: 'hover:bg-red-900' },
    { id: 'SERIES', label: 'Series', icon: PlaySquare, color: 'bg-zinc-800', hover: 'hover:bg-red-900' },
    { id: 'SETTINGS', label: 'Ajustes', icon: Settings, color: 'bg-zinc-900', hover: 'hover:bg-zinc-800' },
  ];

  const expiryDate = auth.user_info.exp_date 
    ? new Date(parseInt(auth.user_info.exp_date) * 1000).toLocaleDateString()
    : 'Ilimitado';

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-[#050505] relative">
      {/* Background gradients */}
      <div className="absolute top-0 right-0 w-[50%] h-[50%] bg-red-950/10 blur-[150px] rounded-full -z-10"></div>
      
      {/* Header */}
      <header className="p-8 flex items-center justify-between bg-zinc-950/20 backdrop-blur-md border-b border-zinc-900">
        <div className="flex items-center gap-5">
          <div className="w-14 h-14 bg-red-600 rounded-2xl flex items-center justify-center shadow-lg shadow-red-950/40 rotate-3">
            <Crown className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-tighter">KING TV</h1>
            <div className="flex items-center gap-4 text-[10px] text-zinc-500 font-bold uppercase tracking-widest">
              <span className="flex items-center gap-1.5"><User size={12} className="text-red-500" /> {auth.user_info.username}</span>
              <span className="flex items-center gap-1.5"><Clock size={12} className="text-red-500" /> Vence: {expiryDate}</span>
            </div>
          </div>
        </div>
        <button 
          onClick={onLogout}
          className="p-4 bg-zinc-900/50 hover:bg-red-600/20 rounded-2xl transition-all border border-zinc-800 group"
        >
          <LogOut size={24} className="text-zinc-500 group-hover:text-red-500 transition-colors" />
        </button>
      </header>

      {/* Grid Content */}
      <main className="flex-1 p-10 overflow-y-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => navigate(item.id as ViewState)}
              className={`group relative flex flex-col items-center justify-center gap-6 ${item.color} ${item.hover} rounded-[2rem] p-10 transition-all duration-500 transform hover:-translate-y-3 hover:shadow-2xl shadow-red-950/20 border border-white/5 overflow-hidden`}
            >
              <div className="p-6 bg-white/5 rounded-3xl group-hover:scale-110 group-hover:bg-white/10 transition-all duration-500">
                <item.icon size={56} className="text-white" />
              </div>
              <span className="text-2xl font-black text-white tracking-tight uppercase italic">{item.label}</span>
              
              {/* Glow effect */}
              <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-red-500/20 blur-[40px] rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
            </button>
          ))}
        </div>

        {/* Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16 max-w-7xl mx-auto">
          <div className="bg-zinc-900/30 backdrop-blur-xl p-8 rounded-[2rem] border border-zinc-800/50 group hover:border-red-900/50 transition-colors">
            <h3 className="text-zinc-600 text-[10px] font-black uppercase tracking-[0.2em] mb-3">Estado de Cuenta</h3>
            <p className="text-2xl font-black flex items-center gap-3">
              <span className="w-3 h-3 bg-red-600 rounded-full animate-pulse"></span>
              PREMIUM VIP
            </p>
          </div>
          <div className="bg-zinc-900/30 backdrop-blur-xl p-8 rounded-[2rem] border border-zinc-800/50 group hover:border-red-900/50 transition-colors">
            <h3 className="text-zinc-600 text-[10px] font-black uppercase tracking-[0.2em] mb-3">Conexiones</h3>
            <p className="text-2xl font-black text-red-500">{auth.user_info.active_cons} <span className="text-zinc-700 text-lg">/ {auth.user_info.max_connections}</span></p>
          </div>
          <div className="bg-zinc-900/30 backdrop-blur-xl p-8 rounded-[2rem] border border-zinc-800/50 group hover:border-red-900/50 transition-colors">
            <h3 className="text-zinc-600 text-[10px] font-black uppercase tracking-[0.2em] mb-3">Información Soporte</h3>
            <p className="text-sm font-bold text-zinc-400">Contacte a su proveedor para renovaciones o actualizaciones.</p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
