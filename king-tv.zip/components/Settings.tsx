
import React, { useState } from 'react';
import { ChevronLeft, Globe, ShieldCheck, User, Crown } from 'lucide-react';
import { AuthResponse } from '../types';

interface SettingsProps {
  auth: AuthResponse;
  host: string;
  onBack: () => void;
  setHost: (host: string) => void;
}

const Settings: React.FC<SettingsProps> = ({ auth, host, onBack, setHost }) => {
  const [newHost, setNewHost] = useState(host);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setHost(newHost);
    localStorage.setItem('iptv_host', newHost);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#050505] flex flex-col relative">
      <div className="absolute top-0 left-0 w-full h-[50%] bg-gradient-to-b from-red-950/10 to-transparent -z-10"></div>
      
      <header className="p-10 flex items-center gap-8 bg-zinc-950/20 backdrop-blur-md">
        <button onClick={onBack} className="p-4 bg-red-700 hover:bg-red-800 rounded-2xl transition-all shadow-xl shadow-red-950/20">
          <ChevronLeft size={32} />
        </button>
        <h1 className="text-4xl font-black italic tracking-tighter uppercase">Configuración</h1>
      </header>

      <main className="flex-1 max-w-5xl mx-auto w-full p-10 space-y-12">
        {/* DNS Configuration */}
        <section className="bg-zinc-900/20 backdrop-blur-3xl rounded-[2.5rem] border border-white/5 overflow-hidden shadow-2xl">
          <div className="p-8 bg-red-700/10 border-b border-red-900/20 flex items-center gap-4">
            <Globe className="text-red-500" size={32} />
            <h2 className="text-2xl font-black uppercase italic tracking-tighter">Servidor DNS</h2>
          </div>
          <div className="p-10 space-y-8">
            <p className="text-zinc-500 text-sm font-medium leading-relaxed">Personalice la dirección de alojamiento para su servicio de televisión. Los cambios se aplicarán globalmente tras el reinicio.</p>
            <div className="space-y-3">
              <label className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.4em] ml-2">Dirección URL del Servicio</label>
              <input 
                type="text"
                value={newHost}
                onChange={(e) => setNewHost(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-[1.5rem] py-5 px-8 text-2xl font-mono text-red-500 focus:outline-none focus:ring-2 focus:ring-red-700 transition-all shadow-inner"
              />
            </div>
            <button 
              onClick={handleSave}
              className={`w-full py-5 rounded-[1.5rem] text-lg font-black uppercase tracking-[0.2em] transition-all shadow-2xl ${saved ? 'bg-green-600' : 'bg-red-600 hover:bg-red-700 active:scale-[0.98]'}`}
            >
              {saved ? 'Cambios Guardados' : 'Aplicar Nuevo DNS'}
            </button>
          </div>
        </section>

        {/* Account Info */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <section className="bg-zinc-900/20 backdrop-blur-3xl rounded-[2.5rem] border border-white/5 p-10 flex flex-col gap-6 shadow-xl group hover:border-red-900/30 transition-all">
             <div className="flex items-center gap-4 text-red-500 font-black uppercase tracking-tighter italic">
                <div className="p-3 bg-red-600/10 rounded-2xl"><User size={28} /></div>
                <span className="text-xl">Perfil de Usuario</span>
             </div>
             <div className="space-y-4">
                <div className="flex justify-between border-b border-zinc-800 pb-3">
                  <span className="text-zinc-600 text-[10px] font-black uppercase tracking-widest">Username</span>
                  <span className="font-bold text-white uppercase">{auth.user_info.username}</span>
                </div>
                <div className="flex justify-between border-b border-zinc-800 pb-3">
                  <span className="text-zinc-600 text-[10px] font-black uppercase tracking-widest">Status</span>
                  <span className="font-black text-red-500 uppercase italic tracking-tighter">Premium VIP</span>
                </div>
                <div className="flex justify-between border-zinc-800">
                  <span className="text-zinc-600 text-[10px] font-black uppercase tracking-widest">Formatos</span>
                  <span className="font-bold text-zinc-400">{auth.user_info.allowed_output_formats.join(', ')}</span>
                </div>
             </div>
          </section>

          <section className="bg-zinc-900/20 backdrop-blur-3xl rounded-[2.5rem] border border-white/5 p-10 flex flex-col gap-6 shadow-xl group hover:border-red-900/30 transition-all">
             <div className="flex items-center gap-4 text-red-500 font-black uppercase tracking-tighter italic">
                <div className="p-3 bg-red-600/10 rounded-2xl"><Crown size={28} /></div>
                <span className="text-xl">Aplicación KING TV</span>
             </div>
             <div className="space-y-4">
                <div className="flex justify-between border-b border-zinc-800 pb-3">
                  <span className="text-zinc-600 text-[10px] font-black uppercase tracking-widest">Versión</span>
                  <span className="font-bold text-white">4.1.0-KING</span>
                </div>
                <div className="flex justify-between border-b border-zinc-800 pb-3">
                  <span className="text-zinc-600 text-[10px] font-black uppercase tracking-widest">Protocolo</span>
                  <span className="font-bold text-white">{auth.server_info.server_protocol}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-600 text-[10px] font-black uppercase tracking-widest">Kernel</span>
                  <span className="font-black text-red-600 uppercase italic">Titan Engine</span>
                </div>
             </div>
          </section>
        </div>
      </main>
    </div>
  );
};

export default Settings;
