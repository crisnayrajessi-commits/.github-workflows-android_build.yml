
import React, { useEffect, useRef, useState } from 'react';
import { ChevronLeft, Play, Pause, Volume2, VolumeX, Maximize, Settings, Globe } from 'lucide-react';
import { Stream } from '../types';
import * as xtream from '../services/xtream';

interface PlayerProps {
  stream: Stream;
  host: string;
  username: string;
  password: string;
  onBack: () => void;
}

const Player: React.FC<PlayerProps> = ({ stream, host, username, password, onBack }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [audioTracks, setAudioTracks] = useState<any[]>([]);
  const [showSettings, setShowSettings] = useState(false);
  const controlsTimeout = useRef<number | null>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    let streamUrl = '';
    if (stream.stream_type === 'live') {
      streamUrl = xtream.getStreamUrl(host, username, password, stream.stream_id);
    } else if (stream.stream_type === 'movie') {
      streamUrl = xtream.getVodUrl(host, username, password, stream.stream_id, stream.container_extension);
    } else {
      streamUrl = xtream.getSeriesUrl(host, username, password, stream.stream_id, stream.container_extension);
    }

    video.src = streamUrl;
    video.play().catch(console.error);

    const handleLoadedMetadata = () => {
      // @ts-ignore
      if (video.audioTracks) {
        // @ts-ignore
        setAudioTracks(Array.from(video.audioTracks));
      }
    };

    video.addEventListener('loadedmetadata', handleLoadedMetadata);
    return () => {
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
    };
  }, [stream, host, username, password]);

  const togglePlay = () => {
    if (videoRef.current?.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current?.pause();
      setIsPlaying(false);
    }
  };

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeout.current) window.clearTimeout(controlsTimeout.current);
    controlsTimeout.current = window.setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  };

  const switchLanguage = (index: number) => {
    const video = videoRef.current;
    // @ts-ignore
    if (video && video.audioTracks) {
      // @ts-ignore
      for (let i = 0; i < video.audioTracks.length; i++) {
        // @ts-ignore
        video.audioTracks[i].enabled = i === index;
      }
      setShowSettings(false);
    }
  };

  return (
    <div 
      className="relative w-full h-screen bg-black overflow-hidden group"
      onMouseMove={handleMouseMove}
    >
      <video 
        ref={videoRef}
        className="w-full h-full cursor-pointer"
        autoPlay
        playsInline
        onClick={togglePlay}
      />

      {/* Top Controls */}
      <div className={`absolute top-0 left-0 right-0 p-10 bg-gradient-to-b from-black via-black/40 to-transparent transition-opacity duration-700 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        <div className="flex items-center gap-8 max-w-7xl mx-auto">
          <button onClick={onBack} className="p-4 bg-red-700 hover:bg-red-800 rounded-2xl transition-all shadow-xl shadow-red-950/20">
            <ChevronLeft size={32} />
          </button>
          <div>
            <h2 className="text-3xl font-black italic tracking-tighter uppercase">{stream.name}</h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="w-2 h-2 bg-red-600 rounded-full animate-pulse"></span>
              <p className="text-red-500 uppercase text-[10px] font-black tracking-[0.3em]">{stream.stream_type}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Center Overlay */}
      {!isPlaying && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="bg-red-600/10 p-12 rounded-[3rem] border border-red-500/30 backdrop-blur-3xl shadow-2xl shadow-red-950/40">
            <Play size={100} fill="white" className="text-white" />
          </div>
        </div>
      )}

      {/* Bottom Controls */}
      <div className={`absolute bottom-0 left-0 right-0 p-10 bg-gradient-to-t from-black via-black/40 to-transparent transition-opacity duration-700 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-10">
            <button onClick={togglePlay} className="text-white hover:text-red-500 transition-colors drop-shadow-lg">
              {isPlaying ? <Pause size={40} fill="currentColor" /> : <Play size={40} fill="currentColor" />}
            </button>
            <button onClick={() => setIsMuted(!isMuted)} className="text-white hover:text-red-500 transition-colors drop-shadow-lg">
              {isMuted ? <VolumeX size={40} /> : <Volume2 size={40} />}
            </button>
          </div>

          <div className="flex items-center gap-8">
            <button 
              className="px-6 py-3 bg-zinc-900/60 hover:bg-red-700 rounded-2xl transition-all border border-zinc-800 flex items-center gap-3 backdrop-blur-md group"
              onClick={() => setShowSettings(!showSettings)}
            >
              <Globe size={24} className="text-red-500 group-hover:text-white transition-colors" />
              <span className="text-xs font-black uppercase tracking-widest">Idiomas</span>
            </button>
            <button 
              className="p-3 bg-zinc-900/60 hover:bg-red-700 rounded-2xl transition-all border border-zinc-800 backdrop-blur-md"
              onClick={() => videoRef.current?.requestFullscreen()}
            >
              <Maximize size={24} />
            </button>
          </div>
        </div>
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <div className="absolute bottom-32 right-10 w-80 bg-zinc-950/90 backdrop-blur-[3rem] border border-red-900/30 rounded-[2.5rem] p-6 shadow-[0_0_50px_rgba(150,0,0,0.3)] animate-in slide-in-from-bottom-5">
          <div className="flex items-center gap-3 mb-6 text-red-500 font-black italic border-b border-red-900/20 pb-4 uppercase tracking-tighter">
             <Settings size={20} />
             <span>Ajustes de Audio</span>
          </div>
          <div className="space-y-2">
            {audioTracks.length > 0 ? audioTracks.map((track, i) => (
              <button
                key={i}
                onClick={() => switchLanguage(i)}
                className={`w-full text-left px-5 py-3.5 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${track.enabled ? 'bg-red-600 text-white' : 'hover:bg-white/5 text-zinc-500'}`}
              >
                Pista {i + 1} ({track.language || 'Default'})
              </button>
            )) : (
              <p className="text-[10px] text-zinc-600 font-bold uppercase p-4 text-center tracking-widest leading-relaxed">No se detectaron pistas adicionales para este stream.</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Player;
