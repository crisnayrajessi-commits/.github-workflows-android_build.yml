
import React, { useState, useMemo } from 'react';
import { ChevronLeft, Search, Play, Star, Loader2 } from 'lucide-react';
import { Category, Stream } from '../types';

interface ContentListProps {
  type: 'live' | 'movie' | 'series';
  categories: Category[];
  streams: Stream[];
  loading: boolean;
  onSelectStream: (stream: Stream) => void;
  onBack: () => void;
  onCategoryChange: (categoryId: string) => void;
}

const ContentList: React.FC<ContentListProps> = ({ 
  type, categories, streams, loading, onSelectStream, onBack, onCategoryChange 
}) => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredStreams = useMemo(() => {
    return streams.filter(s => 
      s.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [streams, searchQuery]);

  return (
    <div className="flex h-screen bg-[#050505] overflow-hidden">
      {/* Sidebar Categories */}
      <aside className="w-72 bg-zinc-950 border-r border-zinc-900 flex flex-col">
        <div className="p-8 border-b border-zinc-900 flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-red-600/20 rounded-xl transition-all border border-transparent hover:border-red-900/50 group">
            <ChevronLeft size={24} className="group-hover:text-red-500 transition-colors" />
          </button>
          <h2 className="text-xl font-black italic tracking-tighter uppercase">{type === 'live' ? 'En Vivo' : type === 'movie' ? 'Cine' : 'Series'}</h2>
        </div>
        
        <div className="flex-1 overflow-y-auto p-5 space-y-2">
          <button
            onClick={() => { setActiveCategory('all'); onCategoryChange('all'); }}
            className={`w-full text-left px-5 py-4 rounded-2xl transition-all font-bold uppercase text-xs tracking-widest ${activeCategory === 'all' ? 'bg-red-700 text-white shadow-lg shadow-red-950/40 translate-x-1' : 'text-zinc-500 hover:bg-zinc-900'}`}
          >
            Todo el Contenido
          </button>
          {categories.map(cat => (
            <button
              key={cat.category_id}
              onClick={() => { setActiveCategory(cat.category_id); onCategoryChange(cat.category_id); }}
              className={`w-full text-left px-5 py-4 rounded-2xl transition-all font-bold uppercase text-[10px] tracking-tight truncate ${activeCategory === cat.category_id ? 'bg-red-700 text-white shadow-lg shadow-red-950/40 translate-x-1' : 'text-zinc-600 hover:bg-zinc-900 hover:text-zinc-300'}`}
            >
              {cat.category_name}
            </button>
          ))}
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative">
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-red-900/5 to-transparent pointer-events-none"></div>
        
        <header className="p-8 bg-zinc-950/40 backdrop-blur-xl flex items-center justify-between border-b border-zinc-900/50 z-10">
          <div className="relative w-full max-w-md group">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-zinc-600 group-focus-within:text-red-500" size={18} />
            <input 
              type="text"
              placeholder="Buscar título..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-zinc-900/60 border border-zinc-800/80 rounded-[1.25rem] py-4 pl-14 pr-5 focus:outline-none focus:ring-2 focus:ring-red-700 transition-all placeholder:text-zinc-700"
            />
          </div>
          <div className="hidden lg:flex items-center gap-4">
            <span className="text-zinc-600 text-[10px] font-black uppercase tracking-[0.2em]">{filteredStreams.length} Disponibles</span>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-10">
          {loading ? (
            <div className="h-full flex flex-col items-center justify-center gap-5">
              <div className="relative">
                <Loader2 className="animate-spin text-red-600" size={64} />
                <div className="absolute inset-0 blur-xl bg-red-600/20 rounded-full"></div>
              </div>
              <p className="text-zinc-500 font-black uppercase tracking-[0.3em] text-xs animate-pulse">Cargando Catálogo</p>
            </div>
          ) : (
            <div className={`grid gap-8 ${type === 'live' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-2 md:grid-cols-4 lg:grid-cols-5 2xl:grid-cols-6'}`}>
              {filteredStreams.map((stream) => (
                <button
                  key={stream.stream_id}
                  onClick={() => onSelectStream(stream)}
                  className="group relative flex flex-col gap-3 text-left focus:outline-none"
                >
                  <div className={`relative overflow-hidden rounded-[2rem] bg-zinc-900 shadow-xl transition-all duration-500 group-hover:scale-[1.03] group-hover:shadow-red-900/30 group-hover:ring-2 group-hover:ring-red-700 border border-white/5 ${type === 'live' ? 'aspect-video' : 'aspect-[2/3]'}`}>
                    {stream.stream_icon ? (
                      <img src={stream.stream_icon} alt={stream.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-zinc-800">
                        <Play size={40} className="text-zinc-700 group-hover:text-red-600 transition-colors" />
                      </div>
                    )}
                    
                    {/* Overlay Info */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-5">
                       <div className="flex items-center gap-2 mb-2">
                          {stream.rating && <span className="bg-yellow-500 text-black text-[9px] font-black px-2 py-0.5 rounded flex items-center gap-1"><Star size={10} fill="black" /> {stream.rating}</span>}
                          {stream.year && <span className="bg-red-600/80 backdrop-blur-md text-white text-[9px] font-black px-2 py-0.5 rounded tracking-tighter">{stream.year}</span>}
                       </div>
                       <p className="text-sm font-black text-white leading-tight">{stream.name}</p>
                    </div>
                  </div>
                  {type === 'live' && (
                    <div className="flex items-center justify-between px-3">
                      <span className="text-[11px] font-black uppercase tracking-tight truncate pr-4 text-zinc-300">{stream.name}</span>
                      <span className="bg-red-600 text-white text-[8px] font-black px-2 py-1 rounded-full uppercase tracking-widest italic animate-pulse">Live</span>
                    </div>
                  )}
                  {type !== 'live' && (
                    <div className="px-3">
                      <p className="text-[11px] font-bold text-zinc-400 line-clamp-1 group-hover:text-white transition-colors">{stream.name}</p>
                    </div>
                  )}
                </button>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default ContentList;
