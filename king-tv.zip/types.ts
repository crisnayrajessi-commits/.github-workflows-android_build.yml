
export interface UserInfo {
  username: string;
  password?: string;
  status: string;
  exp_date: string;
  is_trial: string;
  active_cons: string;
  created_at: string;
  max_connections: string;
  allowed_output_formats: string[];
}

export interface ServerInfo {
  url: string;
  port: string;
  https_port: string;
  server_protocol: string;
  rtmp_port: string;
  timezone: string;
  timestamp_now: number;
  time_now: string;
}

export interface AuthResponse {
  user_info: UserInfo;
  server_info: ServerInfo;
}

export interface Category {
  category_id: string;
  category_name: string;
  parent_id: number;
}

export interface Stream {
  num: number;
  name: string;
  stream_type: 'live' | 'movie' | 'series';
  stream_id: number;
  stream_icon: string;
  added: string;
  category_id: string;
  container_extension?: string;
  rating?: string;
  year?: string;
}

export type ViewState = 'LOGIN' | 'DASHBOARD' | 'LIVE_TV' | 'MOVIES' | 'SERIES' | 'PLAYER' | 'SETTINGS';

export interface AppState {
  view: ViewState;
  auth: AuthResponse | null;
  selectedCategory: string | null;
  selectedStream: Stream | null;
  host: string;
}
